@echo off
chcp 65001 >nul
title HYDRA CHEAT ENGINE :: v9.6.2
mode con: cols=80 lines=30
color 05
cls

:: Agreement Screen
:eula
cls
echo.
echo              ██╗  ██╗██╗   ██╗██████╗ ██████╗  █████╗
echo              ██║  ██║╚██╗ ██╔╝██╔══██╗██╔══██╗██╔══██╗
echo              ███████║ ╚████╔╝ ██║  ██║██████╔╝███████║
echo              ██╔══██║  ╚██╔╝  ██║  ██║██╔══██╗██╔══██║
echo              ██║  ██║   ██║   ██████╔╝██║  ██║██║  ██║
echo              ╚═╝  ╚═╝   ╚═╝   ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝
echo.
echo           ┌───────────────────────────────────────────┐
echo           │             USER AGREEMENT                │
echo           └───────────────────────────────────────────┘
echo.
echo    TERMS OF SERVICE / END USER LICENSE AGREEMENT
echo    By registering, logging in, clicking "Accept", or using any
echo    functionality of the Service, you confirm that you have read,
echo    fully agree, unconditionally accept, and undertake to comply
echo    with all terms of this Agreement and related documents.
echo    The complete User Agreement is available in the "User agreement"
echo    folder (file: "User agreement.bat"). Key provisions include:
echo.
echo    ┌───────────────────────────────────────────────┐
echo    │   [1] ACCEPT THE AGREEMENT AND CONTINUE       │
echo    │   [2] EXIT                                    │
echo    └───────────────────────────────────────────────┘
echo.
choice /c 12 /n /m "    [HYDRA-CHEAT] Select option (1-2): "
if errorlevel 2 exit
if errorlevel 1 goto run_as_admin

:run_as_admin
cls
echo.
echo Now run Hydra.exe and Hydra-uninstaller.exe as Administrator,
echo then press Enter to continue...
pause >nul

:: Main Menu
:menu
cls
echo.
echo              ██╗  ██╗██╗   ██╗██████╗ ██████╗  █████╗
echo              ██║  ██║╚██╗ ██╔╝██╔══██╗██╔══██╗██╔══██╗
echo              ███████║ ╚████╔╝ ██║  ██║██████╔╝███████║
echo              ██╔══██║  ╚██╔╝  ██║  ██║██╔══██╗██╔══██║
echo              ██║  ██║   ██║   ██████╔╝██║  ██║██║  ██║
echo              ╚═╝  ╚═╝   ╚═╝   ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝
echo.
echo              ╔═══════════════════════════════════════╗
echo              ║                                       ║
echo              ║   [1] ACTIVATE CHEAT SYSTEM           ║
echo              ║   [2] EXIT HYDRA CONSOLE              ║
echo              ║                                       ║
echo              ╚═══════════════════════════════════════╝
echo.
echo                  HYDRA SYSTEMS (c) 2021-2025
echo                Licensed for authorized use only
echo.
choice /c 12 /n /m "    [HYDRA-CHEAT] Select option (1-2): "
if errorlevel 2 exit
if errorlevel 1 goto activate

:activate
cls
echo.
echo              ██╗  ██╗██╗   ██╗██████╗ ██████╗  █████╗
echo              ██║  ██║╚██╗ ██╔╝██╔══██╗██╔══██╗██╔══██╗
echo              ███████║ ╚████╔╝ ██║  ██║██████╔╝███████║
echo              ██╔══██║  ╚██╔╝  ██║  ██║██╔══██╗██╔══██║
echo              ██║  ██║   ██║   ██████╔╝██║  ██║██║  ██║
echo              ╚═╝  ╚═╝   ╚═╝   ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝
echo.
echo              INITIALIZING CHEAT ENGINE v9.6.2...
echo.
setlocal enabledelayedexpansion
for /l %%i in (1,1,20) do (
    cls
    echo.
    echo              ██╗  ██╗██╗   ██╗██████╗ ██████╗  █████╗
    echo              ██║  ██║╚██╗ ██╔╝██╔══██╗██╔══██╗██╔══██╗
    echo              ███████║ ╚████╔╝ ██║  ██║██████╔╝███████║
    echo              ██╔══██║  ╚██╔╝  ██║  ██║██╔══██╗██╔══██║
    echo              ██║  ██║   ██║   ██████╔╝██║  ██║██║  ██║
    echo              ╚═╝  ╚═╝   ╚═╝   ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝
    echo.
    echo              INITIALIZING CHEAT ENGINE v9.6.2...
    echo.
    set /a width=%%i*2
    set "bar="
    for /l %%j in (1,1,!width!) do set "bar=!bar!■"
    set /a percent=%%i*5
    echo              [!bar!] !percent!%%
    ping -n 1 127.0.0.1 >nul
)
cls
echo.
echo              ██╗  ██╗██╗   ██╗██████╗ ██████╗  █████╗
echo              ██║  ██║╚██╗ ██╔╝██╔══██╗██╔══██╗██╔══██╗
echo              ███████║ ╚████╔╝ ██║  ██║██████╔╝███████║
echo              ██╔══██║  ╚██╔╝  ██║  ██║██╔══██╗██╔══██║
echo              ██║  ██║   ██║   ██████╔╝██║  ██║██║  ██║
echo              ╚═╝  ╚═╝   ╚═╝   ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝
echo.
echo              CHEAT SYSTEM ACTIVATED [STATUS: ONLINE]
echo.
echo              WAITING FOR YOU TO LAUNCH CS:GO/CS2...
echo              PLEASE START THE GAME TO CONTINUE
echo.
pause
goto menu
